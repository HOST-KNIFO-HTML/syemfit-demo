from flask import Flask, render_template
import sqlite3

app = Flask(__name__)

def get_clients():
    conn = sqlite3.connect('database.db')
    c = conn.cursor()
    c.execute("SELECT name, plan FROM clients")
    data = c.fetchall()
    conn.close()
    return data

@app.route('/')
def index():
    clients = get_clients()
    return render_template('index.html', clients=clients)

if __name__ == '__main__':
    app.run(debug=True)
